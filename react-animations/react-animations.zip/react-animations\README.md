### About this Workshop
React provides a way to animate parts of your UI with the ReactCSSTransitionGroup add-on component.

### Instructions
1. Download and extract the [zip](https://github.com/adamelliotfields/treehouse-react/raw/master/react-animations/react-animations.zip).
2. Run `npm install` or `yarn install`.
3. Run `npm run serve` or `yarn serve`.
