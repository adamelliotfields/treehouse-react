# About this Workshop
Learn different methods for fetching external data in React, and how to display the data in your app.

### Instructions
1. Download and extract the [zip](https://github.com/adamelliotfields/treehouse-react/raw/master/react-data-fetching/react-data-fetching.zip).
2. Run `npm install` or `yarn install`.
3. Run `npm run serve` or `yarn serve`.
