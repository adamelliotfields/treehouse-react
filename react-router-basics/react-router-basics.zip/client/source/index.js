import React from 'react';
import { render } from 'react-dom';

import './css/index.css';

import App from './jsx/containers/App.jsx';

render(<App />, document.getElementById('root'));
